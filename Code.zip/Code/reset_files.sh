rm -rf spark_jobs/output_aggregations
rm -rf spark_jobs/datasets
rm -rf spark_jobs/checkpoint
mkdir spark_jobs/output_aggregations spark_jobs/datasets spark_jobs/checkpoint